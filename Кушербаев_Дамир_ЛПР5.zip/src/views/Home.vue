<template>
    <div>
        <h2>Home page</h2>
        <p>Lorem ipsum dolor sit amet, consect,evptbmmiobe</p>
        <router-link to="/todos">Todos</router-link>
    </div>
</template>